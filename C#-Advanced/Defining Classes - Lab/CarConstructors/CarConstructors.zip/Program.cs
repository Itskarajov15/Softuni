﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car("Mercedes", "S class", 2021, 200, 10);
        }
    }
}
